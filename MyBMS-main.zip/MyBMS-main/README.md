# MyBMS
Book Management System 
To start the Project run sqll.py
it will create required tables and call the main program.

Alterations Required :-
Assign name of your database to the variable mydatabase.
Assign password of your dtabase to the variable mypass.
